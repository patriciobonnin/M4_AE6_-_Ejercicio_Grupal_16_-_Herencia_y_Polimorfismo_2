public class Main {

    public static void main(String[] args){


        Listado lista = new Listado();

        Cliente cliente = new Cliente("Maria","10/05/1997","16743569-2",14565454-5,"Jara","7897987","Modelo",
                1,"La Granja","Stgo",25);

        Cliente cliente2 = new Cliente("Monica","18/09/1992","18763421-2",19217821-8,"Hernandez","24312321","Capital",
                2,"Hollywood","Las Condes",36);

        Profesional profesional = new Profesional("Roberto","10/05/1965","1542456-2",
                "Ingeniero Mecanico","05/11/1856");

        Profesional profesional2 = new Profesional("Ivan","15/08/2001","1664756-3",
                "Programador ","05/11/1700");

        Administrativo administrativo = new Administrativo("Patricio","20/03/1850","168864756-6",
                "Constructor","5 años construyendo programadores");


        lista.addUsuario(cliente);
        lista.addUsuario(cliente2);
        lista.addUsuario(profesional);
        lista.addUsuario(profesional2);
        lista.addUsuario(administrativo);

        lista.mostrarUsuario();


    }
}
