import java.util.ArrayList;
import java.util.List;

public class Listado {

    List<Usuario> lista;

    public Listado(){

        this.lista = new ArrayList<>();

    }

    public void addUsuario( Usuario usuario){
        this.lista.add(usuario);
    }

    public void mostrarUsuario(){

        for (Usuario usuario: lista){
            usuario.analizarUsuario();
        }

    }
}
