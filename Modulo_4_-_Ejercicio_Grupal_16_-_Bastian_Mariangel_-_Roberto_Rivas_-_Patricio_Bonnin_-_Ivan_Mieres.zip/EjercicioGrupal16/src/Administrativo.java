public class Administrativo extends Usuario {

    private String area;
    private String expPrevia;

    public Administrativo(String area, String expPrevia) {
        this.area = area;
        this.expPrevia = expPrevia;
    }

    public Administrativo(String nombre, String fechaNacimiento, String run, String area, String expPrevia) {
        super(nombre, fechaNacimiento, run);
        this.area = area;
        this.expPrevia = expPrevia;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getExpPrevia() {
        return expPrevia;
    }

    public void setExpPrevia(String expPrevia) {
        this.expPrevia = expPrevia;
    }

    @Override
    public void analizarUsuario(){
        super.analizarUsuario();
        System.out.println("Área : "+this.area);
        System.out.println("Experiencia previa: "+ this.expPrevia);
    }

    @Override
    public String toString() {
        return "Administrativo{" +
                "area='" + area + '\'' +
                ", expPrevia='" + expPrevia + '\'' +
                '}';
    }


}
